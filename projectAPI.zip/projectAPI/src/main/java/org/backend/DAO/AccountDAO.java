package org.backend.DAO;

import org.backend.entity.Account;

import java.util.List;

public interface AccountDAO {
    List<Account> getAll();
    boolean insert(Account account);
    boolean update(String id, Account account);
    boolean delete(String id);
    List<Account> getById(String id);
}
