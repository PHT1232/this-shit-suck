package org.backend.DAO;

import org.backend.entity.Student;

import java.util.List;

public interface StudentDAO {
    List<Student> getAll();
    boolean insert(Student student);
    boolean delete(String id);
    boolean update(String id, Student student);
    List<Student> getById(String id);
}
