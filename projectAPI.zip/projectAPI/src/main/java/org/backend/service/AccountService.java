package org.backend.service;


import org.backend.models.AccountDTO;

import java.util.List;

public interface AccountService {
    List<AccountDTO> getAll();
    boolean insert(AccountDTO account);
    boolean update(String id, AccountDTO account);
    boolean delete(String id);
    List<AccountDTO> getById(String id);
}
