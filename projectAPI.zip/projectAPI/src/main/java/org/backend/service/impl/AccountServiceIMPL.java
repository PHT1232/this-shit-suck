package org.backend.service.impl;

import org.backend.DAO.AccountDAO;
import org.backend.entity.Account;
import org.backend.models.AccountDTO;
import org.backend.service.AccountService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class AccountServiceIMPL implements AccountService {

    @Autowired
    AccountDAO accountDAO;

    @Override
    public List<AccountDTO> getAll() {
        List<AccountDTO> lsDTO = new ArrayList<>();
        List<Account> ls = accountDAO.getAll();
        for (Account ac : ls) {
            AccountDTO acDT = new AccountDTO();
            acDT.setId(ac.getId());
            acDT.setUserName(ac.getUserName());
            acDT.setPassword(ac.getPassword());
            acDT.setTeacherId(ac.getTeacherId());
            acDT.setStudentId(ac.getStudentId());
            acDT.setAuthority(ac.getAuthority());
            lsDTO.add(acDT);
        }
        return lsDTO;
    }

    @Override
    public boolean insert(AccountDTO account) {
        Account ac = new Account();
        ac.setUserName(account.getUserName());
        ac.setPassword(account.getPassword());
        ac.setStudentId(account.getStudentId());
        ac.setTeacherId(account.getTeacherId());
        ac.setAuthority(account.getAuthority());
        return accountDAO.insert(ac);
    }

    @Override
    public boolean update(String id, AccountDTO account) {
        Account ac = new Account();
        ac.setUserName(account.getUserName());
        ac.setPassword(account.getPassword());
        ac.setStudentId(account.getStudentId());
        ac.setTeacherId(account.getTeacherId());
        ac.setAuthority(account.getAuthority());
        return accountDAO.update(id, ac);
    }

    @Override
    public boolean delete(String id) {
        return accountDAO.delete(id);
    }

    @Override
    public List<AccountDTO> getById(String id) {
        return null;
    }
}
